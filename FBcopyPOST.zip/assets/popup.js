function modifyDOM() {
    //You can play with your DOM here or check URL against your regex
    let userContentWrapper = document.querySelector('.userContentWrapper');

    if(!userContentWrapper) {
    	return false;
    } else {
    	return document.querySelector('.userContentWrapper').innerHTML;
    }
}

function getDOM() {
	chrome.tabs.executeScript({
	    code: '(' + modifyDOM + ')();'
	}, (results) => {

		if(results[0] !== false) {
		    let DOM = $(results[0]);
		    let titlePost = DOM.find('.userContent p').text();
		    let replyPosts = DOM.find('.UFICommentContent');
		    let comment = "";

		    replyPosts.each(function(){
		    	let userComment = $(this);
		    	userComment.find('a').attr('target','_blank');
		    	userComment.find('a.UFICommentCloseButton').remove();
		    	userComment.find('img').remove();
		    	userComment.find('.UFICommentActorName').append(':');
		    	userComment.find('.UFICommentActorName').wrap('<strong class="username"></strong>');
		    	userComment.find('> div~div').css('margin-top', '15px');
		    	comment += userComment[0].innerHTML;
		    });

		    $('#post-print').html('').append(
		    	'<h2 class="title" style="margin-bottom: 30px;">' + titlePost + '</h2>',
		    	comment
		    );
		} else {
			$('#post-print').html('').append('<p style="margin: 0px; text-align: center;">Nothing to display on this website.</p>');
		}
	});
}

chrome.tabs.executeScript({file: 'assets/inject.js'}, function() { setTimeout(function(){ getDOM(); }, 3000); });
