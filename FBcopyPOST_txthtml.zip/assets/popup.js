options = {
	"indent":"auto",
	"indent-spaces":2,
	"wrap": 9999,
	"markup":true,
	"output-xml":false,
	"numeric-entities":true,
	"quote-marks":true,
	"quote-nbsp":false,
	"show-body-only":true,
	"quote-ampersand":false,
	"break-before-br":true,
	"uppercase-tags":false,
	"uppercase-attributes":false,
	"drop-font-tags":true,
	"tidy-mark":false,
	"show-warnings": false,
}

function modifyDOM() {
    //You can play with your DOM here or check URL against your regex
    let userContentWrapper = document.querySelector('.userContentWrapper');
    if(!userContentWrapper) {
    	return false;
    } else {
    	return document.querySelector('.userContentWrapper').innerHTML;
    }
}

function getDOM() {
	chrome.tabs.executeScript({
	    code: '(' + modifyDOM + ')();'
	}, (results) => {
		if(results[0] !== false) {
		    let DOM = $(results[0]);
		    let titlePost = DOM.find('.userContent p').text();
		    let replyPosts = DOM.find('.UFICommentContent');
		    let comment = "";
		    replyPosts.each(function(){
		    	let userComment = $(this);
		    	userComment.find('a').attr('target','_blank');
		    	userComment.find('a.UFICommentCloseButton').remove();
		    	userComment.find('img').remove();
		    	userComment.find('.UFICommentActorName').removeAttr("href");
		    	userComment.find('.UFICommentActorName').append(':');
		    	userComment.find('.UFICommentActorName').wrap('<strong>');
		    	userComment.find('.UFICommentReactionsBling').parent().remove();
		    	userComment.find('> div~div').addClass('location');
				userComment.find('*').each(function() {
					if ($.trim($(this).text()) == "") {
						$(this).remove();
					}
				});
		    	comment += userComment[0].innerHTML + "<br>";
		    });
		    $('#html').show();
		    $('footer').show();
		    $('#post-print').css('padding-bottom', '50px');
		    $('#post-print').html('').append(
		    	'<h2 class="title" style="margin-bottom: 30px;">' + titlePost + '</h2>',
		    	comment
		    );
		    var html = document.querySelector("#post-print").innerHTML;
			var result = tidy_html5(html, options);
			$("#post").html(result);
			$("#post").find('br').remove();
			$('#post .location').each(function(){
				var txtcontent = $(this).prop("textContent");
				var split = txtcontent.split(/\n/);
				var txtcontentnew = "";
				for (var i = 0; i < split.length; i++) {
					split[i] = split[i].trim();
					if(split[i] !== "") {
						txtcontentnew += split[i] + "\r\n";
					}
				}
				$(this).html(txtcontentnew);
			});
			$('#post > div').each(function(){
				$(this)[0].innerHTML = $.trim($(this)[0].innerHTML.replace('<strong>', '[leftstrong]').replace('</strong>', '[rightstrong]'));
				$(this)[0].innerHTML = $.trim($(this)[0].innerHTML.replace(/<\/?.+?>/ig, ''));
			});
			$('#post > h2')[0].innerHTML = $.trim($('#post > h2')[0].innerHTML) + "\r\n";
			$('#post')[0].innerHTML = $('#post')[0].innerHTML.replace(/<\/?.+?>/ig, '');
			$('#html').val($.trim($('#post')[0].innerHTML.replace(/\[leftstrong]/ig, '<strong>').replace(/\[rightstrong]/ig, '</strong>')));
			var json = JSON.stringify($('#html').val());
			json = json.replace(/\\n\\n/g, "\\n");
			json = JSON.parse(json);
			$('#html').val(json);
		} else {
			$('#post-print').html('').append('<p style="margin: 0px; text-align: center;">Nothing to display on this website.</p>');
		}
	});
}

chrome.tabs.executeScript({file: 'assets/inject.js'}, function() { setTimeout(function(){ getDOM(); }, 3500); });

$('.btn-text').on('click', function(){
  var postPrint = document.querySelector('#post-print');
  var range = document.createRange();
  range.selectNode(postPrint);
  window.getSelection().addRange(range);
  document.execCommand('copy');
  window.getSelection().removeAllRanges();
});

var clipboard = new ClipboardJS('.btn-html');
